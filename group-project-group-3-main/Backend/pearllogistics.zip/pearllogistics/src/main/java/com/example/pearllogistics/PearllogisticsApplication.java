package com.example.pearllogistics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PearllogisticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PearllogisticsApplication.class, args);
	}

}
